package com.mycompany.prog_part1;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Part 3: keeps the arrays that hold every message and provides the
 * features of the "Stored Messages" menu (display, search, delete, report).
 */
public class MessageStore {

    /** The JSON file that Part 2 stores messages in. */
    public static final String DEFAULT_JSON_FILE = "messages.json";

    // ------------------------------------------------------------------
    // The five required arrays (ArrayLists, so they can grow and shrink)
    // ------------------------------------------------------------------

    /** Contains all the messages sent. */
    private static final List<MessageRecord> sentMessages = new ArrayList<>();

    /** Contains all the messages that were disregarded. */
    private static final List<MessageRecord> disregardedMessages =
            new ArrayList<>();

    /** Contains the stored messages, read from the JSON file. */
    private static final List<MessageRecord> storedMessages =
            new ArrayList<>();

    /**
     * Contains all the message hashes. Parallel to messageIDs: position n
     * holds the hash and the ID of the same message (the order is sent,
     * then stored, then disregarded messages).
     */
    private static final List<String> messageHashes = new ArrayList<>();

    /** Contains all the message IDs (parallel to messageHashes). */
    private static final List<String> messageIDs = new ArrayList<>();

    /** The cell number of the logged in user (the sender of the messages). */
    private static String sender = "Unknown";

    private MessageStore() {
        // static helper class, no objects needed
    }

    // ------------------------------------------------------------------
    // Populating the arrays
    // ------------------------------------------------------------------

    public static void setSender(String senderNumber) {
        sender = senderNumber;
    }

    public static String getSender() {
        return sender;
    }

    /** Adds a message to the Sent Message array. */
    public static void addSentMessage(MessageRecord record) {
        sentMessages.add(record);
        refreshIdentifierArrays();
    }

    /** Adds a Part 2 message to the Sent Message array. */
    public static void addSentMessage(Messages message) {
        addSentMessage(MessageRecord.from(message, sender));
    }

    /** Adds a message to the Disregarded Messages array. */
    public static void addDisregardedMessage(MessageRecord record) {
        disregardedMessages.add(record);
        refreshIdentifierArrays();
    }

    /** Adds a Part 2 message to the Disregarded Messages array. */
    public static void addDisregardedMessage(Messages message) {
        addDisregardedMessage(MessageRecord.from(message, sender));
    }

    /**
     * Refills the Message ID and Message Hash arrays so that they stay
     * parallel to the messages in the other arrays.
     */
    private static void refreshIdentifierArrays() {
        messageIDs.clear();
        messageHashes.clear();
        for (MessageRecord record : allMessages()) {
            messageIDs.add(record.getMessageID());
            messageHashes.add(record.getMessageHash());
        }
    }

    /**
     * Reads the JSON file into the Stored Messages array. The file may hold
     * one JSON object after another (the way Part 2 appends them) or a JSON
     * array of objects, so the reader is lenient and keeps reading until the
     * end of the file. Any messages already in the array are replaced.
     *
     * Reference: Google (n.d.) Gson API documentation: JsonParser,
     * JsonReader and JsonObject. Available at:
     * https://github.com/google/gson/blob/main/UserGuide.md
     *
     * @param file the JSON file
     * @throws IOException if the file cannot be read
     */
    public static void loadStoredMessages(Path file) throws IOException {
        storedMessages.clear();

        if (Files.exists(file) && Files.size(file) > 0) {
            try (Reader fileReader =
                         Files.newBufferedReader(file, StandardCharsets.UTF_8);
                 JsonReader reader = new JsonReader(fileReader)) {

                reader.setLenient(true);

                while (reader.peek() != JsonToken.END_DOCUMENT) {
                    JsonElement element = JsonParser.parseReader(reader);

                    if (element.isJsonArray()) {
                        for (JsonElement item : element.getAsJsonArray()) {
                            addFromJson(item);
                        }
                    } else {
                        addFromJson(element);
                    }
                }
            }
        }

        refreshIdentifierArrays();
    }

    /** Reads the default JSON file (messages.json) into the array. */
    public static void loadStoredMessages() throws IOException {
        loadStoredMessages(Paths.get(DEFAULT_JSON_FILE));
    }

    /** Reads the default JSON file into the array and reports any error. */
    public static void reloadStoredMessages() {
        try {
            loadStoredMessages();
        } catch (IOException e) {
            System.out.println("Stored messages could not be read: "
                    + e.getMessage());
        }
    }

    /** Turns one JSON object into a record and adds it to the array. */
    private static void addFromJson(JsonElement element) {
        if (!element.isJsonObject()) {
            return;
        }
        JsonObject object = element.getAsJsonObject();
        storedMessages.add(new MessageRecord(
                text(object, "messageID"),
                text(object, "messageHash"),
                // Part 2 does not save the sender, so the logged in user is used
                text(object, "sender").isEmpty() ? sender
                        : text(object, "sender"),
                text(object, "recipient"),
                text(object, "message")));
    }

    private static String text(JsonObject object, String key) {
        return object.has(key) && !object.get(key).isJsonNull()
                ? object.get(key).getAsString()
                : "";
    }

    /**
     * Writes the Stored Messages array back to the JSON file in the same
     * layout that Part 2 uses (one object after another).
     */
    private static void saveStoredMessages(Path file) throws IOException {
        try (Writer writer =
                     Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            for (MessageRecord record : storedMessages) {
                writer.write("{\n");
                writer.write("  \"messageID\": \""
                        + Main.escapeJson(record.getMessageID()) + "\",\n");
                writer.write("  \"messageHash\": \""
                        + Main.escapeJson(record.getMessageHash()) + "\",\n");
                writer.write("  \"recipient\": \""
                        + Main.escapeJson(record.getRecipient()) + "\",\n");
                writer.write("  \"message\": \""
                        + Main.escapeJson(record.getMessage()) + "\"\n");
                writer.write("}\n");
            }
        }
    }

    /** Empties every array (used by the unit tests). */
    public static void clearAll() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
    }

    /**
     * Adds a record to the Stored Messages array without reading a file
     * (used by the unit tests; the app reads the JSON file instead).
     */
    public static void addStoredMessage(MessageRecord record) {
        storedMessages.add(record);
        refreshIdentifierArrays();
    }

    // ------------------------------------------------------------------
    // Getters for the arrays
    // ------------------------------------------------------------------

    public static List<MessageRecord> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public static List<MessageRecord> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    public static List<MessageRecord> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }

    public static List<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public static List<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }

    /** @return the text of every sent message, in the order they were sent */
    public static List<String> getSentMessageTexts() {
        return textsOf(sentMessages);
    }

    /** @return the text of every disregarded message */
    public static List<String> getDisregardedMessageTexts() {
        return textsOf(disregardedMessages);
    }

    /** @return the text of every stored message */
    public static List<String> getStoredMessageTexts() {
        return textsOf(storedMessages);
    }

    private static List<String> textsOf(List<MessageRecord> records) {
        List<String> texts = new ArrayList<>();
        for (MessageRecord record : records) {
            texts.add(record.getMessage());
        }
        return texts;
    }

    // ------------------------------------------------------------------
    // 2a. Display the sender and recipient of all stored messages
    // ------------------------------------------------------------------

    public static String displaySenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        int number = 1;
        for (MessageRecord record : storedMessages) {
            sb.append(number++)
                    .append(") Sender: ").append(record.getSender())
                    .append(" | Recipient: ").append(record.getRecipient())
                    .append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------
    // 2b. Display the longest stored message
    // ------------------------------------------------------------------

    /**
     * Finds the longest stored message.
     *
     * @return the text of the longest message, or null if none are stored
     */
    public static String longestStoredMessage() {
        String longest = null;
        for (MessageRecord record : storedMessages) {
            String text = record.getMessage();
            if (longest == null || text.length() > longest.length()) {
                longest = text;
            }
        }
        return longest;
    }

    // ------------------------------------------------------------------
    // 2c. Search for a message ID
    // ------------------------------------------------------------------

    /**
     * Searches the sent, stored and disregarded messages for a message ID.
     *
     * @param messageID the ID to look for
     * @return the matching message, or null if it was not found
     */
    public static MessageRecord searchByMessageID(String messageID) {
        // the position of the ID in the ID array is the position of the message
        int position = messageIDs.indexOf(messageID);
        if (position < 0) {
            return null;
        }
        return allMessages().get(position);
    }

    /** @return the recipient and message for an ID, ready to display */
    public static String displayByMessageID(String messageID) {
        MessageRecord record = searchByMessageID(messageID);
        if (record == null) {
            return "No message with message ID " + messageID + " was found.";
        }
        return "Recipient: " + record.getRecipient()
                + System.lineSeparator()
                + "Message: " + record.getMessage();
    }

    // ------------------------------------------------------------------
    // 2d. Search for all the messages for a particular recipient
    // ------------------------------------------------------------------

    /**
     * Finds every message that was sent or stored for a recipient.
     *
     * @param recipient the recipient's cell number
     * @return the text of each matching message
     */
    public static List<String> searchByRecipient(String recipient) {
        List<String> found = new ArrayList<>();
        for (MessageRecord record : sentMessages) {
            if (record.getRecipient().equals(recipient)) {
                found.add(record.getMessage());
            }
        }
        for (MessageRecord record : storedMessages) {
            if (record.getRecipient().equals(recipient)) {
                found.add(record.getMessage());
            }
        }
        return found;
    }

    /** @return the messages for a recipient, ready to display */
    public static String displayByRecipient(String recipient) {
        List<String> found = searchByRecipient(recipient);
        if (found.isEmpty()) {
            return "No messages were found for " + recipient + ".";
        }
        StringBuilder sb = new StringBuilder();
        for (String text : found) {
            sb.append("- ").append(text).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------
    // 2e. Delete a message using the message hash
    // ------------------------------------------------------------------

    /**
     * Deletes a message using its message hash. The message is removed from
     * whichever array holds it, the ID and hash arrays are refreshed and,
     * if it was stored, the JSON file is updated.
     *
     * @param hash the message hash
     * @param file the JSON file that holds the stored messages
     * @return a message saying whether the delete worked
     */
    public static String deleteByMessageHash(String hash, Path file) {
        int position = messageHashes.indexOf(hash);
        if (position < 0) {
            return "No message with message hash " + hash + " was found.";
        }
        MessageRecord target = allMessages().get(position);

        boolean wasStored = storedMessages.remove(target);
        sentMessages.remove(target);
        disregardedMessages.remove(target);
        refreshIdentifierArrays();

        if (wasStored) {
            try {
                saveStoredMessages(file);
            } catch (IOException e) {
                return "Message deleted, but the JSON file could not be "
                        + "updated: " + e.getMessage();
            }
        }

        return "Message: \"" + target.getMessage() + "\" successfully deleted.";
    }

    /** Deletes a message using the default JSON file. */
    public static String deleteByMessageHash(String hash) {
        return deleteByMessageHash(hash, Paths.get(DEFAULT_JSON_FILE));
    }

    // ------------------------------------------------------------------
    // 2f. Display a report of all the stored messages
    // ------------------------------------------------------------------

    /**
     * Builds a report that lists the full details (ID, hash, sender,
     * recipient and message) of every stored message, followed by the
     * sent messages.
     *
     * @return the report
     */
    public static String displayReport() {
        if (storedMessages.isEmpty() && sentMessages.isEmpty()) {
            return "There are no messages to report on.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("========== MESSAGE REPORT ==========")
                .append(System.lineSeparator());
        appendReportSection(sb, "STORED MESSAGES", storedMessages);
        appendReportSection(sb, "SENT MESSAGES", sentMessages);
        return sb.toString().trim();
    }

    private static void appendReportSection(StringBuilder sb, String title,
                                            List<MessageRecord> records) {
        sb.append(System.lineSeparator()).append("--- ").append(title)
                .append(" ---").append(System.lineSeparator());
        if (records.isEmpty()) {
            sb.append("None").append(System.lineSeparator());
            return;
        }
        int number = 1;
        for (MessageRecord record : records) {
            sb.append(System.lineSeparator())
                    .append("Message ").append(number++)
                    .append(System.lineSeparator())
                    .append("Message ID: ").append(record.getMessageID())
                    .append(System.lineSeparator())
                    .append("Message Hash: ").append(record.getMessageHash())
                    .append(System.lineSeparator())
                    .append("Sender: ").append(record.getSender())
                    .append(System.lineSeparator())
                    .append("Recipient: ").append(record.getRecipient())
                    .append(System.lineSeparator())
                    .append("Message: ").append(record.getMessage())
                    .append(System.lineSeparator());
        }
    }

    // ------------------------------------------------------------------
    // The Stored Messages menu (main menu option 4)
    // ------------------------------------------------------------------

    /**
     * Runs the Stored Messages menu until the user goes back.
     *
     * @param input the scanner to read user input from
     */
    public static void runStoredMessagesMenu(java.util.Scanner input) {

        boolean back = false;
        while (!back) {

            System.out.println();
            System.out.println("------- STORED MESSAGES -------");
            System.out.println("1. Display the sender and recipient of "
                    + "all stored messages");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search for a message ID");
            System.out.println("4. Search for all messages for a recipient");
            System.out.println("5. Delete a message using the message hash");
            System.out.println("6. Display a report of all messages");
            System.out.println("7. Back to the main menu");
            System.out.print("Choose an option: ");

            int option;
            try {
                option = Integer.parseInt(input.nextLine().trim());
            } catch (NumberFormatException e) {
                option = 0;
            }
            System.out.println();

            switch (option) {
                case 1:
                    System.out.println(displaySenderAndRecipient());
                    break;
                case 2:
                    String longest = longestStoredMessage();
                    System.out.println(longest == null
                            ? "There are no stored messages."
                            : "Longest stored message: " + longest);
                    break;
                case 3:
                    System.out.print("Enter the message ID: ");
                    System.out.println(
                            displayByMessageID(input.nextLine().trim()));
                    break;
                case 4:
                    System.out.print("Enter the recipient cell number: ");
                    System.out.println(
                            displayByRecipient(input.nextLine().trim()));
                    break;
                case 5:
                    System.out.print("Enter the message hash: ");
                    System.out.println(
                            deleteByMessageHash(input.nextLine().trim()));
                    break;
                case 6:
                    System.out.println(displayReport());
                    break;
                case 7:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1 to 7.");
            }
        }
    }

    // ------------------------------------------------------------------

    /** @return every message: sent, then stored, then disregarded */
    private static List<MessageRecord> allMessages() {
        List<MessageRecord> all = new ArrayList<>(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        return all;
    }
}
