package com.mycompany.prog_part1;

/**
 * Part 3: a simple data holder for one message. Objects of this class are
 * kept in the sent, disregarded and stored message arrays.
 */
public class MessageRecord {

    private final String messageID;
    private final String messageHash;
    private final String sender;
    private final String recipient;
    private final String message;

    public MessageRecord(String messageID, String messageHash, String sender,
                         String recipient, String message) {
        this.messageID = messageID;
        this.messageHash = messageHash;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
    }

    /** Creates a record from a message made in Part 2. */
    public static MessageRecord from(Messages source, String sender) {
        return new MessageRecord(source.getMessageID(),
                source.getMessageHash(), sender,
                source.getRecipient(), source.getMessageText());
    }

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    /** @return the sender, or "Unknown" when the file did not hold one */
    public String getSender() {
        return sender == null || sender.isEmpty() ? "Unknown" : sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }
}
