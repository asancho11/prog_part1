package com.mycompany.prog_part1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/**
 * Part 3 unit tests, using the five test data messages from the POE.
 *
 * Message 1 - Sent, Message 2 - Stored, Message 3 - Disregard,
 * Message 4 - Sent, Message 5 - Stored.
 */
public class MessageStoreTest {

    private static final String MSG_1 = "Did you get the cake?";
    private static final String MSG_2 =
            "Where are you? You are late! I have asked you to be on time.";
    private static final String MSG_3 = "Yohoooo, I am at your gate.";
    private static final String MSG_4 = "It is dinner time!";
    private static final String MSG_5 = "Ok, I am leaving without you.";

    private static final String RECIPIENT_1 = "+27834557896";
    private static final String RECIPIENT_2 = "+27838884567";
    private static final String RECIPIENT_3 = "+27834484567";
    // The POE gives no recipient for message 4 (only the ID 0838884567),
    // so a different number is used to keep it out of recipient searches.
    private static final String RECIPIENT_4 = "+27830000004";

    @TempDir
    Path tempDir;

    private Path jsonFile;
    private MessageRecord message2;

    @BeforeEach
    public void populateArrays() throws IOException {
        MessageStore.clearAll();
        MessageStore.setSender("+27718693002");
        jsonFile = tempDir.resolve("messages.json");

        // Test Data Message 1 - Sent
        MessageStore.addSentMessage(new MessageRecord("1100000001",
                "11:0:DIDCAKE?", "+27718693002", RECIPIENT_1, MSG_1));

        // Test Data Message 2 - Stored (written to the JSON file)
        message2 = new MessageRecord("2200000002", "22:1:WHERETIME.",
                "+27718693002", RECIPIENT_2, MSG_2);

        // Test Data Message 3 - Disregard
        MessageStore.addDisregardedMessage(new MessageRecord("3300000003",
                "33:1:YOHOOOO,GATE.", "+27718693002", RECIPIENT_3, MSG_3));

        // Test Data Message 4 - Sent (message ID 0838884567)
        MessageStore.addSentMessage(new MessageRecord("0838884567",
                "08:1:ITTIME!", "+27718693002", RECIPIENT_4, MSG_4));

        // Test Data Message 5 - Stored (written to the JSON file)
        MessageRecord message5 = new MessageRecord("5500000005",
                "55:1:OKYOU.", "+27718693002", RECIPIENT_2, MSG_5);

        // the stored messages are written in the layout Part 2 uses
        // (one JSON object after another) and read back into the array
        Files.writeString(jsonFile, asJson(message2) + asJson(message5));
        MessageStore.loadStoredMessages(jsonFile);
    }

    /** Writes a record the same way Main.storeMessageAsJson does. */
    private static String asJson(MessageRecord r) {
        return "{\n"
                + "  \"messageID\": \"" + r.getMessageID() + "\",\n"
                + "  \"messageHash\": \"" + r.getMessageHash() + "\",\n"
                + "  \"recipient\": \"" + r.getRecipient() + "\",\n"
                + "  \"message\": \"" + Main.escapeJson(r.getMessage())
                + "\"\n}\n";
    }

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        assertEquals(Arrays.asList("Did you get the cake?",
                        "It is dinner time!"),
                MessageStore.getSentMessageTexts());
    }

    @Test
    public void testDisregardedMessagesArrayCorrectlyPopulated() {
        assertEquals(List.of("Yohoooo, I am at your gate."),
                MessageStore.getDisregardedMessageTexts());
    }

    @Test
    public void testStoredMessagesArrayReadFromJson() {
        assertEquals(Arrays.asList(MSG_2, MSG_5),
                MessageStore.getStoredMessageTexts());
    }

    @Test
    public void testExistingPartTwoJsonFileCanBeRead() throws IOException {
        // a file holding a single object, as left behind by Part 2
        Path single = tempDir.resolve("single.json");
        Files.writeString(single, "{\n  \"messageID\": \"3477400204\",\n"
                + "  \"messageHash\": \"34:0:BALLERBACK\",\n"
                + "  \"recipient\": \"+27683793279\",\n"
                + "  \"message\": \"baller is back\"\n}\n");

        MessageStore.loadStoredMessages(single);

        assertEquals(List.of("baller is back"),
                MessageStore.getStoredMessageTexts());
    }

    @Test
    public void testHashAndIdArraysContainAllMessages() {
        assertEquals(5, MessageStore.getMessageIDs().size());
        assertEquals(5, MessageStore.getMessageHashes().size());
        assertTrue(MessageStore.getMessageIDs().contains("0838884567"));
    }

    @Test
    public void testIdAndHashArraysAreParallel() {
        int position = MessageStore.getMessageIDs().indexOf("2200000002");
        assertEquals(message2.getMessageHash(),
                MessageStore.getMessageHashes().get(position));
    }

    @Test
    public void testDisplayTheLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you "
                        + "to be on time.",
                MessageStore.longestStoredMessage());
    }

    @Test
    public void testSearchForMessageID() {
        MessageRecord found = MessageStore.searchByMessageID("0838884567");
        assertNotNull(found);
        assertEquals("It is dinner time!", found.getMessage());
    }

    @Test
    public void testSearchForMessageIDNotFound() {
        assertNull(MessageStore.searchByMessageID("9999999999"));
    }

    @Test
    public void testSearchAllMessagesForARecipient() {
        assertEquals(Arrays.asList(
                        "Where are you? You are late! I have asked you "
                                + "to be on time.",
                        "Ok, I am leaving without you."),
                MessageStore.searchByRecipient("+27838884567"));
    }

    @Test
    public void testDeleteMessageUsingMessageHash() throws IOException {
        String result = MessageStore.deleteByMessageHash(
                message2.getMessageHash(), jsonFile);

        assertEquals("Message: \"Where are you? You are late! I have asked "
                + "you to be on time.\" successfully deleted.", result);

        // removed from the array, the hash array and the JSON file
        assertEquals(List.of(MSG_5), MessageStore.getStoredMessageTexts());
        assertFalse(MessageStore.getMessageHashes()
                .contains(message2.getMessageHash()));
        assertFalse(Files.readString(jsonFile).contains("Where are you?"));

        // the file can still be read back after the delete
        MessageStore.loadStoredMessages(jsonFile);
        assertEquals(List.of(MSG_5), MessageStore.getStoredMessageTexts());
    }

    @Test
    public void testDeleteMessageWithUnknownHash() {
        assertEquals("No message with message hash XX:0:NONE was found.",
                MessageStore.deleteByMessageHash("XX:0:NONE", jsonFile));
    }

    @Test
    public void testDisplayReport() {
        String report = MessageStore.displayReport();

        for (MessageRecord stored : MessageStore.getStoredMessages()) {
            assertTrue(report.contains("Message Hash: "
                    + stored.getMessageHash()));
            assertTrue(report.contains("Recipient: "
                    + stored.getRecipient()));
            assertTrue(report.contains("Message: " + stored.getMessage()));
        }
        // the report also lists the sent messages
        assertTrue(report.contains("Message: " + MSG_1));
        assertTrue(report.contains("Message: " + MSG_4));
        // disregarded messages are not part of the report
        assertFalse(report.contains(MSG_3));
    }

    @Test
    public void testDisplaySenderAndRecipient() {
        String result = MessageStore.displaySenderAndRecipient();
        assertTrue(result.contains("Recipient: " + RECIPIENT_2));
    }
}
