package com.mycompany.prog_part1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
/**
 * unit tests for the login class
 * @author Student
 */
public class LoginTest {

    @Test
    public void testCorrectUsername() {
        Login login = new Login("John", "Smith");

        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testIncorrectUsername() {
        Login login = new Login("John", "Smith");

        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testCorrectPassword() {
        Login login = new Login("John", "Smith");

        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testIncorrectPassword() {
        Login login = new Login("John", "Smith");

        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCorrectCellPhoneNumber() {
        Login login = new Login("John", "Smith");

        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testIncorrectCellPhoneNumber() {
        Login login = new Login("John", "Smith");

        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testSuccessfulLogin() {
        Login login = new Login("John", "Smith");

        login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertTrue(
                login.loginUser(
                        "kyl_1",
                        "Ch&&sec@ke99!"
                )
        );
    }

    @Test
    public void testFailedLogin() {
        Login login = new Login("John", "Smith");

        login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertFalse(
                login.loginUser(
                        "wrong",
                        "wrong"
                )
        );
    }
}