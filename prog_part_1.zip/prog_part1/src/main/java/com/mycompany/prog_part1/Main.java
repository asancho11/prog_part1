package com.mycompany.prog_part1;

import java.util.Scanner;

/**
 * Main class for the Part 1 registration and login application.
 */
public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("========================================");
        System.out.println("       REGISTRATION AND LOGIN");
        System.out.println("========================================");

        // Get the user's personal details
        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();
//checks the user's login details.
        // Create a Login object
        Login login = new Login(firstName, lastName);
//collects and validates user registration details.
        // Registration
        System.out.println();
        System.out.println("----------- REGISTRATION -----------");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter South African cell phone number: ");
        String cellPhoneNumber = input.nextLine();

        // Register the user
        String registrationMessage =
                login.registerUser(
                        username,
                        password,
                        cellPhoneNumber
                );

        System.out.println();
        System.out.println(registrationMessage);

        // Only continue to login if registration was successful
        if (registrationMessage.equals("Registration successful.")) {

            System.out.println();
            System.out.println("----------- LOGIN -----------");

            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            // Check login details
            boolean loginSuccessful =
                    login.loginUser(
                            loginUsername,
                            loginPassword
                    );

            // Display login status
            String loginStatus =
                    login.returnLoginStatus(loginSuccessful);

            System.out.println();
            System.out.println(loginStatus);

        } else {

            System.out.println();
            System.out.println("Please correct your registration details "
                    + "and try again.");
        }

        input.close();
    }
}