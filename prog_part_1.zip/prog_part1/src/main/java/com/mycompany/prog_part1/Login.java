package com.mycompany.prog_part1;

import java.util.regex.Pattern;

/**
 * The Login class handles user registration and login.
 */
public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    /**
     * Constructor for the Login class.
     *
     * @param firstName the user's first name
     * @param lastName the user's last name
     */
    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Checks whether the username contains an underscore
     * and is no more than five characters long.
     *
     * @param username the username to check
     * @return true if the username is correctly formatted
     */
    public boolean checkUserName(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    /**
     * Checks whether the password meets the required
     * complexity rules.
     *
     * The password must:
     * - contain at least eight characters
     * - contain a capital letter
     * - contain a number
     * - contain a special character
     *
     * @param password the password to check
     * @return true if the password meets the requirements
     */
    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = password.matches(".*[A-Z].*");
        boolean hasNumber = password.matches(".*[0-9].*");
        boolean hasSpecialCharacter =
                password.matches(".*[^a-zA-Z0-9].*");

        return hasCapitalLetter
                && hasNumber
                && hasSpecialCharacter;
    }

    /**
     * Checks whether the South African cell phone number
     * contains the international country code and is
     * correctly formatted.
     *
     * Regular expression research/reference:
     * Oracle Java Documentation - java.util.regex.Pattern
     *
     * @param cellPhoneNumber the cell phone number to check
     * @return true if the cell phone number is correctly formatted
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {

        String regex = "^\\+27[0-9]{9}$";

        return cellPhoneNumber != null
                && Pattern.matches(regex, cellPhoneNumber);
    }

    /**
     * Registers the user after checking all registration
     * requirements was successful,before registering user.
     *
     * @param username the username
     * @param password the password
     * @param cellPhoneNumber the cell phone number
     * @return the appropriate registration message
     */
    public String registerUser(String username,
                               String password,
                               String cellPhoneNumber) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted; "
                    + "please ensure that your username contains "
                    + "an underscore and is no more than five "
                    + "characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; "
                    + "please ensure that the password contains "
                    + "at least eight characters, a capital letter, "
                    + "a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell number is incorrectly formatted or does "
                    + "not contain an international code; please "
                    + "correct the number and try again.";
        }

        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;

        return "Registration successful.";
    }

    /**
     * Checks whether the username and password entered match
     * the registered details.
     *
     * @param username the entered username
     * @param password the entered password
     * @return true if the login details are correct
     */
    public boolean loginUser(String username, String password) {

        return this.username != null
                && this.password != null
                && this.username.equals(username)
                && this.password.equals(password);
    }
/**
 * manages user registration and login validation.
 */
    /**
     * Returns the appropriate login status message.
     *
     * @param loginSuccessful whether the login was successful
     * @return the login status message
     */
    public String returnLoginStatus(boolean loginSuccessful) {

        if (loginSuccessful) {
            return "Welcome back " + firstName + ", " + lastName
                    + " it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }
}