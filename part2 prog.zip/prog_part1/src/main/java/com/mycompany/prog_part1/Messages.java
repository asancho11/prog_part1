/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog_part1;

import java.util.Random;

public final class Messages {

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    public Messages(int messageNumber, String recipient,
                   String messageText) {

        Random random = new Random();

        long randomNumber =
                1_000_000_000L
                + (long) (random.nextDouble() * 9_000_000_000L);

        this.messageID = String.valueOf(randomNumber);
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;

        this.messageHash = createMessageHash();
    }

    public String createMessageHash() {

        if (messageText == null || messageText.trim().isEmpty()) {
            return "";
        }

        String[] words = messageText.trim().split("\\s+");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        String idStart = messageID.substring(0, 2);

        return (idStart + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }public String validateMessageLength() {
    if (messageText == null) {
        return "Message ready to send.";
    }

    if (messageText.length() <= 250) {
        return "Message ready to send.";
    }

    int excess = messageText.length() - 250;

    return "Message exceeds 250 characters by "
            + excess
            + "; please reduce the size.";
}

    public String getMessageHash() {
        return messageHash;
    }

public boolean checkMessageID() {
    return messageID != null
            && messageID.length() <= 10;
}


public String checkRecipientCell() {
    if (recipient != null
            && recipient.matches("\\+\\d{11,15}")) {
        return "Cell phone number successfully captured.";
    }

    return "Cell phone number is incorrectly formatted "
            + "or does not contain an international code. "
            + "Please correct the number and try again.";
}

}

/**
 *
 * @author Student
 */
