
package com.mycompany.prog_part1;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        ArrayList<Messages> messages = new ArrayList<>();

        int messageNumber = 0;

        System.out.println("========================================");
        System.out.println("       REGISTRATION AND LOGIN");
        System.out.println("========================================");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        Login login = new Login(firstName, lastName);

        System.out.println();
        System.out.println("----------- REGISTRATION -----------");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter South African cell phone number: ");
        String cellPhoneNumber = input.nextLine();

        String registrationMessage = login.registerUser(
                username, password, cellPhoneNumber);

        System.out.println();
        System.out.println(registrationMessage);

        if (registrationMessage.equals("Registration successful.")) {

            System.out.println();
            System.out.println("----------- LOGIN -----------");

            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            boolean loginSuccessful = login.loginUser(
                    loginUsername, loginPassword);

            String loginStatus =
                    login.returnLoginStatus(loginSuccessful);

            System.out.println();
            System.out.println(loginStatus);

            if (loginSuccessful) {

                int choice = 0;

                while (choice != 3) {

                    System.out.println();
                    System.out.println("===== MESSAGING MENU =====");
                    System.out.println("1. Send a message");
                    System.out.println("2. Show recently sent messages");
                    System.out.println("3. Quit");
                    System.out.print("Choose an option: ");

                    String menuInput = input.nextLine();

                    try {
                        choice = Integer.parseInt(menuInput);
                    } catch (NumberFormatException e) {
                        choice = 0;
                    }

                    switch (choice) {

                        case 1: {
                            System.out.print(
                                    "Enter recipient cellphone number: ");
                            String recipient = input.nextLine();

                            System.out.print("Enter your message: ");
                            String messageText = input.nextLine();

                            Messages newMessage = new Messages(
                                    messageNumber,
                                    recipient,
                                    messageText);

                            if (!newMessage.checkMessageID()) {
                                System.out.println("Invalid message ID.");
                                break;
                            }

                            String cellStatus =
                                    newMessage.checkRecipientCell();

                            if (!cellStatus.equals(
                                    "Cell phone number successfully captured.")) {
                                System.out.println(cellStatus);
                                break;
                            }

                            String lengthStatus =
                                    newMessage.validateMessageLength();

                            System.out.println(lengthStatus);

                            if (!lengthStatus.equals(
                                    "Message ready to send.")) {
                                break;
                            }

                            System.out.println();
                            System.out.println("1. Send Message");
                            System.out.println("0. Disregard Message");
                            System.out.println(
                                    "2. Store Message to send later");
                            System.out.print("Choose an option: ");

                            String sendChoice = input.nextLine();

                            if (sendChoice.equals("1")) {

                                messages.add(newMessage);
                                messageNumber++;

                                System.out.println(
                                        "Message successfully sent");

                                displayMessage(newMessage);
                                System.out.println(
                                        "Total messages sent: "
                                        + messages.size());

                            } else if (sendChoice.equals("0")) {

                                System.out.println(
                                        "Press 0 to delete the message");
                                System.out.println(
                                        "Message disregarded.");

                            } else if (sendChoice.equals("2")) {

                                storeMessageAsJson(newMessage);
                                messageNumber++;

                            } else {

                                System.out.println("Invalid option.");
                            }

                            break;
                        }

                        case 2:
                            System.out.println("Recently sent messages:");

                            if (messages.isEmpty()) {
                                System.out.println(
                                        "No messages available.");
                            } else {
                                for (Messages message : messages) {
                                    displayMessage(message);
                                }
                            }
                            break;

                        case 3:
                            System.out.println("Goodbye!");
                            break;

                        default:
                            System.out.println(
                                    "Invalid option. Please choose 1, 2, or 3.");
                    }
                }
            }

        } else {
            System.out.println(
                    "Please correct your registration details "
                    + "and try again.");
        }

        input.close();
    }

    public static void displayMessage(Messages message) {
        System.out.println("Message ID: "
                + message.getMessageID());
        System.out.println("Message Hash: "
                + message.getMessageHash());
        System.out.println("Recipient: "
                + message.getRecipient());
        System.out.println("Message: "
                + message.getMessageText());
    }

    public static void storeMessageAsJson(Messages message) {

        try (FileWriter writer =
                new FileWriter("messages.json", true)) {

            writer.write("{\n");
            writer.write("  \"messageID\": \""
                    + escapeJson(message.getMessageID()) + "\",\n");
            writer.write("  \"messageHash\": \""
                    + escapeJson(message.getMessageHash()) + "\",\n");
            writer.write("  \"recipient\": \""
                    + escapeJson(message.getRecipient()) + "\",\n");
            writer.write("  \"message\": \""
                    + escapeJson(message.getMessageText()) + "\"\n");
            writer.write("}\n");

            System.out.println("Message successfully stored");

        } catch (IOException e) {
            System.out.println("Error storing message: "
                    + e.getMessage());
        }
    }

    public static String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
